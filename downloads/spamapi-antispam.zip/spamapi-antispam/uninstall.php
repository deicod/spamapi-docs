<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

require_once __DIR__ . '/includes/class-spamapi-client.php';
require_once __DIR__ . '/includes/class-spamapi-training.php';
$cleanup = static function(): void {
    global $wpdb;
    if (get_option('spamapi_training_schema') || get_option('spamapi_installation_id')) { SpamAPI_Training::disconnect(); }
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}spamapi_training_queue");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}spamapi_training_state");
    $owned_options = $wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name=%s", $wpdb->esc_like('spamapi_training_') . '%', 'spamapi_installation_id');
    foreach ($wpdb->get_col($owned_options) as $option) {
        delete_option($option);
    }
    wp_clear_scheduled_hook('spamapi_training_soon');
    wp_clear_scheduled_hook('spamapi_training_drain');

    delete_option('spamapi_enabled');
    delete_option('spamapi_api_key');
    delete_option('spamapi_api_url');
    delete_option('spamapi_auto_delete_spam');
    delete_option('spamapi_delete_after_days');
    delete_option('spamapi_strictness');
};

if (is_multisite()) {
    $offset = 0;
    do {
        $sites = get_sites(['fields' => 'ids', 'number' => 100, 'offset' => $offset, 'orderby' => 'id', 'order' => 'ASC']);
        foreach ($sites as $site_id) {
            switch_to_blog((int) $site_id);
            try { $cleanup(); }
            finally { restore_current_blog(); }
        }
        $offset += count($sites);
    } while (count($sites) === 100);
} else {
    $cleanup();
}
