<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

delete_option('spamapi_enabled');
delete_option('spamapi_api_key');
delete_option('spamapi_api_url');
delete_option('spamapi_auto_delete_spam');
delete_option('spamapi_delete_after_days');
delete_option('spamapi_strictness');
