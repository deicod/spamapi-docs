=== SpamAPI Anti-Spam ===
Contributors: spamapi
Tags: spam, anti-spam, comment spam, contact form spam, security
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Protect your WordPress site from spam comments and form submissions using SpamAPI's intelligent spam detection powered by AI.

== Description ==

SpamAPI Anti-Spam provides powerful spam protection for your WordPress site using advanced AI-powered detection. It checks comments and form submissions against SpamAPI's intelligent spam detection service.

**Features:**

* AI-powered spam detection with high accuracy
* Protects WordPress comments
* Integrates with popular form plugins (Contact Form 7, Gravity Forms, WPForms)
* Configurable strictness levels
* Usage statistics in the dashboard
* Lightweight and fast

**Form Plugin Support:**

* Contact Form 7
* Gravity Forms
* WPForms

== Installation ==

1. Download https://deicod.github.io/spamapi-docs/downloads/spamapi-antispam.zip
2. In WordPress, open Plugins > Add New Plugin > Upload Plugin, select the ZIP, and click Install Now
3. Activate the plugin and go to Settings > SpamAPI
4. Enter your dashboard API key; the API URL defaults to https://spamapi.de/api/v1
5. Save the settings, test the connection, and enable spam protection

For manual installation, extract the ZIP's spamapi-antispam folder into /wp-content/plugins/ and activate it from Plugins. No Composer installation is required.

== Frequently Asked Questions ==

= Where do I get an API key? =

Sign up for a free account at https://spamapi.de and get your API key from the dashboard.

= Is there a free plan? =

Yes! SpamAPI offers a free plan with 100 API calls per month, perfect for personal blogs.

= Does it work with my form plugin? =

SpamAPI integrates with Contact Form 7, Gravity Forms, and WPForms. More integrations coming soon!

= What happens if the API is unavailable? =

If the SpamAPI service is temporarily unavailable, comments will be allowed through normally. We don't block legitimate content due to service issues.

== Screenshots ==

1. Settings page
2. Usage statistics
3. Comments list with SpamAPI status

== Changelog ==

= 1.0.1 =
* Use the production API URL and dashboard key-management link
* Load the bundled form integrations correctly
* Remove unused automatic-deletion settings

= 1.0.0 =
* Initial release
* Comment spam protection
* Contact Form 7 integration
* Gravity Forms integration
* WPForms integration

== Upgrade Notice ==

= 1.0.1 =
Corrected hosted-service defaults and settings for the public plugin download.

= 1.0.0 =
Initial release.
