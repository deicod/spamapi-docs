=== SpamAPI Anti-Spam ===
Contributors: spamapi
Tags: spam, anti-spam, comment spam, contact form spam, security
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.3
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Protect your WordPress site from spam comments and form submissions using SpamAPI's intelligent spam detection powered by AI.

== Description ==

SpamAPI Anti-Spam provides powerful spam protection for your WordPress site using advanced AI-powered detection. It checks comments and form submissions against SpamAPI's intelligent spam detection service.

**Features:**

* AI-powered spam detection with high accuracy
* Protects WordPress comments
* Integrates with popular form plugins (Contact Form 7, Gravity Forms, WPForms)
* Configurable strictness levels
* Usage statistics in the dashboard
* Lightweight and fast

**Form Plugin Support:**

* Contact Form 7
* Gravity Forms
* WPForms

== Installation ==

Requires WordPress 6.4 or newer and PHP 8.3 or newer. Use a current WordPress
release receiving upstream security fixes; the plugin minimum is a compatibility
floor, not a security-support guarantee for older WordPress releases.

Compatibility checks cover WordPress 6.4 with PHP 8.3 and current WordPress with
PHP 8.3, 8.4 and 8.5. For PHP 8.4 or 8.5, upgrade WordPress to a compatible
release: https://make.wordpress.org/core/handbook/references/php-compatibility-and-wordpress-versions/

1. Download https://deicod.github.io/spamapi-docs/downloads/spamapi-antispam.zip
2. In WordPress, open Plugins > Add New Plugin > Upload Plugin, select the ZIP, and click Install Now
3. Activate the plugin and go to Settings > SpamAPI
4. Enter your dashboard API key; the API URL defaults to https://api.spamapi.de/api/v1
5. Save the settings, test the connection, and enable spam protection

For manual installation, extract the ZIP's spamapi-antispam folder into /wp-content/plugins/ and activate it from Plugins. No Composer installation is required.

== Frequently Asked Questions ==

= Where do I get an API key? =

Sign up for a free account at https://app.spamapi.de/auth/register and get your API key from the dashboard.

= Is there a free plan? =

Yes! SpamAPI offers a free plan with 100 API calls per month, perfect for personal blogs.

= Does it work with my form plugin? =

SpamAPI integrates with Contact Form 7, Gravity Forms, and WPForms. More integrations coming soon!

= What happens if the API is unavailable? =

If the SpamAPI service is temporarily unavailable, comments will be allowed through normally. We don't block legitimate content due to service issues.

== External service and optional shared-model training ==

Normal spam checks send configured submission data to SpamAPI (https://api.spamapi.de).
Privacy: https://app.spamapi.de/privacy ; Terms: https://app.spamapi.de/terms

Shared-model contributions are separately optional, disabled by default, and
available on free and paid accounts. Test Connection retrieves the operator's
contribution-policy notice and configured retention before enabling. Confirm your
authority and visitor disclosures; the setting alone does not establish legal
compliance. Explicit moderation queues minimized comment text, language, opaque
installation/item IDs, label/content revisions, timestamps and prediction links
for SpamAPI's own shared statistical comment model. Separate author names,
emails, IPs and headers are omitted; remaining text/hashes can be personal data.
Automatic approvals, pending status and stored-status backfills are not trusted
human labels. No history uploads automatically.

Queues are bounded to 1000 records and a seven-day event age; settings show
failures and pending work. Use a real scheduler for low-traffic WP-Cron and
`wp spamapi training status|drain|retry` to inspect/deliver/retry. Disabling removes
queued text and requests remote source withdrawal. Confirm disabled server status
before removing credentials/uninstalling; disconnected/offline withdrawals need
account-owner follow-up. Affected models are retired/retrained; deletion does not
automatically unlearn model influence. Details:
https://deicod.github.io/spamapi-docs/guides/wordpress-plugin/#shared-model-contributions

== Screenshots ==

1. Settings page
2. Usage statistics
3. Comments list with SpamAPI status

== Changelog ==

= 1.3.0 =
* The API URL defaults to https://api.spamapi.de/api/v1; spamapi.de serves the SpamAPI website
* Dashboard, sign-up, privacy and terms links point to app.spamapi.de

= 1.2.1 =
* Strict now blocks comments and form submissions from a score of 0.3, as its label says; it previously blocked the same as Balanced
* The SpamAPI column in the comments list follows the strictness setting

= 1.2.0 =
* Require PHP 8.3 and WordPress 6.4 or newer
* Test the minimum WordPress/PHP combination and current WordPress on PHP 8.3, 8.4 and 8.5
* Verify the distributable ZIP installs and activates without Composer dependencies

= 1.1.0 =
* Optional shared-model contributions with explicit policy and durable moderation queue
* Versioned labels, bounded retries, withdrawals and explicit historical backfill
* Truthful queued/ingested/error responses from feedback helpers


= 1.0.1 =
* Use the production API URL and dashboard key-management link
* Load the bundled form integrations correctly
* Remove unused automatic-deletion settings

= 1.0.0 =
* Initial release
* Comment spam protection
* Contact Form 7 integration
* Gravity Forms integration
* WPForms integration

== Upgrade Notice ==

= 1.3.0 =
The hosted API is now at https://api.spamapi.de/api/v1. Earlier installations keep their saved API URL; change it under Settings > SpamAPI.

= 1.2.1 =
Sites set to Strict will block more comments and form submissions than before. Lenient and Balanced are unchanged.

= 1.2.0 =
Requires PHP 8.3 and WordPress 6.4 or newer. Upgrade your server and WordPress before updating the plugin.

= 1.0.1 =
Corrected hosted-service defaults and settings for the public plugin download.

= 1.0.0 =
Initial release.
