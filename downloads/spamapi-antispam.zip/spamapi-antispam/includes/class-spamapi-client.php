<?php
/**
 * SpamAPI HTTP client.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_Client {
    /**
     * API key.
     *
     * @var string
     */
    private string $api_key;

    /**
     * API base URL.
     *
     * @var string
     */
    private string $base_url;


    /**
     * Default request timeout in seconds.
     */
    private const DEFAULT_TIMEOUT = 15;


    private int $timeout = self::DEFAULT_TIMEOUT;

    /**
     * Constructor.
     *
     * @param string $api_key API key.
     * @param string $base_url API base URL.
     */
    public function __construct(string $api_key, string $base_url) {
        $this->api_key = $api_key;
        $this->base_url = rtrim($base_url, '/');
    }

    /**
     * Verify the API key.
     *
     * @return array{valid: bool, plan?: string, usage?: array}
     * @throws SpamAPI_Exception On API error.
     */
    public function verify_key(): array {
        return $this->post('/verify-key', [
            'api_key' => $this->api_key,
            'blog' => get_bloginfo('url'),
        ]);
    }

    /**
     * Check content for spam.
     *
     * @param array $data Comment/form data.
     * @return array{is_spam: bool, score: float, recommendation: string, reasons: array}
     * @throws SpamAPI_Exception On API error.
     */
    public function check(array $data): array {
        $payload = array_merge([
            'api_key' => $this->api_key,
            'blog' => get_bloginfo('url'),
        ], $data);

        return $this->post('/check', $payload);
    }

    /**
     * Submit spam (false negative feedback).
     *
     * @param array $data Comment data.
     * @return array
     * @throws SpamAPI_Exception On API error.
     */
    public function submit_spam(array $data): array {
        $payload = array_merge([
            'api_key' => $this->api_key,
            'blog' => get_bloginfo('url'),
        ], $data);

        return $this->post('/submit-spam', $payload);
    }

    /**
     * Submit ham (false positive feedback).
     *
     * @param array $data Comment data.
     * @return array
     * @throws SpamAPI_Exception On API error.
     */
    public function submit_ham(array $data): array {
        $payload = array_merge([
            'api_key' => $this->api_key,
            'blog' => get_bloginfo('url'),
        ], $data);

        return $this->post('/submit-ham', $payload);
    }

    /**
     * Get usage statistics.
     *
     * @return array{limit: int, used: int, percentage: string, resets_at: string}
     * @throws SpamAPI_Exception On API error.
     */
    public function get_usage(): array {
        return $this->get('/usage');
    }

    /**
     * Make a POST request.
     *
     * @param string $endpoint API endpoint.
     * @param array $data Request data.
     * @return array Response data.
     * @throws SpamAPI_Exception On API error.
     */
    private function post(string $endpoint, array $data): array {
        $url = $this->base_url . $endpoint;

        $response = wp_remote_post($url, [
            'timeout' => $this->timeout,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => $this->get_user_agent(),
            ],
            'body' => wp_json_encode($data),
        ]);

        return $this->handle_response($response);
    }

    /**
     * Make a GET request.
     *
     * @param string $endpoint API endpoint.
     * @param array $params Query parameters.
     * @return array Response data.
     * @throws SpamAPI_Exception On API error.
     */
    private function get(string $endpoint, array $params = []): array {
        $url = $this->base_url . $endpoint;
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        $response = wp_remote_get($url, [
            'timeout' => $this->timeout,
            'headers' => [
                'Accept' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => $this->get_user_agent(),
            ],
        ]);

        return $this->handle_response($response);
    }

    /**
     * Handle API response.
     *
     * @param array|WP_Error $response WordPress HTTP response.
     * @return array Response data.
     * @throws SpamAPI_Exception On API error.
     */
    private function handle_response($response): array {
        if (is_wp_error($response)) {
            throw new SpamAPI_Exception(
                $response->get_error_message(),
                'connection_error'
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($data === null) {
            $data = [];
        }

        if ($status_code >= 400) {
            $error_code = $data['error'] ?? 'unknown_error';
            $error_message = $data['message'] ?? 'An unknown error occurred';
            throw new SpamAPI_Exception($error_message, $error_code, $status_code);
        }

        return $data ?? [];
    }

    /**
     * Get user agent string.
     *
     * @return string
     */
    private function get_user_agent(): string {
        global $wp_version;
        return sprintf(
            'SpamAPI-WordPress/%s WordPress/%s PHP/%s',
            SPAMAPI_VERSION,
            $wp_version,
            PHP_VERSION
        );
    }

    /**
     * Check if API key is configured.
     *
     * @return bool
     */
    public function has_api_key(): bool {
        return !empty($this->api_key);
    }
}

/**
 * SpamAPI Exception.
 */
class SpamAPI_Exception extends Exception {
    /**
     * Error code.
     *
     * @var string
     */
    private string $error_code;

    /**
     * HTTP status code.
     *
     * @var int
     */
    private int $status_code;

    /**
     * Constructor.
     *
     * @param string $message Error message.
     * @param string $code Error code.
     * @param int $status_code HTTP status code.
     */
    public function __construct(string $message, string $code, int $status_code = 0) {
        parent::__construct($message);
        $this->error_code = $code;
        $this->status_code = $status_code;
    }

    /**
     * Get error code.
     *
     * @return string
     */
    public function get_error_code(): string {
        return $this->error_code;
    }

    /**
     * Get HTTP status code.
     *
     * @return int
     */
    public function get_status_code(): int {
        return $this->status_code;
    }
}
