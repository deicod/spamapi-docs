<?php
/** Explicit participation, moderation provenance, and bounded durable delivery. */
class SpamAPI_Training {
    public const POLICY = 'comment-pilot-v1';
    private SpamAPI_Client $client;
    private array $rest_actions = [];
    private const MAX_QUEUE = 1000;
    private const MAX_AGE = 604800;

    public function __construct(SpamAPI_Client $client) { $this->client = $client; }

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$wpdb->prefix}spamapi_training_state (
            comment_id bigint(20) unsigned NOT NULL,
            item_id char(36) NOT NULL,
            revision bigint(20) unsigned NOT NULL DEFAULT 0,
            fingerprint char(64) NOT NULL DEFAULT '',
            content_revision char(64) NOT NULL DEFAULT '',
            lease_until bigint(20) NOT NULL DEFAULT 0,
            lease_token char(36) NOT NULL DEFAULT '',
            PRIMARY KEY  (comment_id),
            UNIQUE KEY item_id (item_id)
        ) ENGINE=InnoDB $charset;");
        dbDelta("CREATE TABLE {$wpdb->prefix}spamapi_training_queue (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_id char(36) NOT NULL,
            kind varchar(10) NOT NULL,
            payload longtext NOT NULL,
            created_at bigint(20) NOT NULL,
            next_at bigint(20) NOT NULL DEFAULT 0,
            attempts int NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY event_id (event_id)
        ) ENGINE=InnoDB $charset;");
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->prefix}spamapi_training_state(comment_id,item_id) VALUES(0,%s)", wp_generate_uuid4()));
        update_option('spamapi_training_schema', 2, false);
        add_option('spamapi_training_enabled', false);
        if (!get_option('spamapi_installation_id')) { add_option('spamapi_installation_id', wp_generate_uuid4(), '', false); }
    }

    public function hooks(): void {
        if ((int) get_option('spamapi_training_schema', 0) !== 2) { self::install(); }
        add_action('transition_comment_status', [$this, 'transition'], 100, 3);
        add_action('unspam_comment', [$this, 'not_spam'], 10, 1);
        add_action('edit_comment', [$this, 'edited'], 100, 1);
        add_action('delete_comment', [$this, 'deleted'], 10, 1);
        add_action('deleted_comment', [$this, 'forget'], 10, 1);
        add_filter('rest_pre_insert_comment', [$this, 'rest_context'], 100, 2);
        add_action('rest_after_insert_comment', [$this, 'rest_finished'], 100, 3);
        add_action('update_option_spamapi_training_enabled', [$this, 'participation_changed'], 10, 2);
        add_action('update_option_spamapi_api_key', [$this, 'credentials_changed'], 10, 2);
        add_action('update_option_spamapi_api_url', [$this, 'credentials_changed'], 10, 2);
        add_action('update_option_home', [$this, 'site_changed'], 10, 2);
        add_action('spamapi_training_drain', [$this, 'drain']);
        if (!wp_next_scheduled('spamapi_training_drain')) { wp_schedule_event(time() + 60, 'hourly', 'spamapi_training_drain'); }
        $this->reconcile_site_binding();
        $this->register_for_inference();
        if (defined('WP_CLI') && WP_CLI) {
            WP_CLI::add_command('spamapi training status', static function() { WP_CLI::line(wp_json_encode(self::status())); });
            WP_CLI::add_command('spamapi training drain', [$this, 'drain']);
            WP_CLI::add_command('spamapi training backfill', [$this, 'backfill']);
            WP_CLI::add_command('spamapi training retry', [$this, 'retry_failed']);
        }
    }

    public function rest_context($prepared, WP_REST_Request $request) {
        $id = (int) $request->get_param('id');
        if ($id && current_user_can('moderate_comments') && current_user_can('edit_comment', $id)) {
            $status = $request->get_param('status');
            if (in_array($status, ['approved', 'spam'], true)) { $this->rest_actions[$id] = $status === 'spam' ? 'spam' : 'ham'; }
        }
        return $prepared;
    }

    public function rest_finished($comment, $request, $creating): void { unset($this->rest_actions[(int) $comment->comment_ID]); }

    private function manual_action(int $id, string $label): bool {
        if (wp_doing_cron() || (defined('WP_CLI') && WP_CLI) || !is_user_logged_in() || !current_user_can('moderate_comments') || !current_user_can('edit_comment', $id)) { return false; }
        if (($this->rest_actions[$id] ?? '') === $label) { return true; }
        if (!is_admin()) { return false; }
        $action = sanitize_key(wp_unslash($_REQUEST['action'] ?? ''));
        if ($action === '-1' || $action === '') { $action = sanitize_key(wp_unslash($_REQUEST['action2'] ?? '')); }
        $allowed = $label === 'spam' ? ['spam', 'spamcomment', 'dim-comment'] : ['approve', 'approvecomment', 'unspam', 'unspamcomment', 'dim-comment'];
        if (!in_array($action, $allowed, true)) { return false; }
        $ids = array_map('absint', (array) ($_REQUEST['delete_comments'] ?? []));
        $single = absint($_REQUEST['c'] ?? $_REQUEST['id'] ?? $_REQUEST['comment_ID'] ?? 0);
        if ($single !== $id && !in_array($id, $ids, true)) { return false; }
        // Core handlers have already checked their nonce before mutating status.
        // Check it again here to avoid trusting unrelated admin plugin updates.
        $nonce = sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'] ?? $_REQUEST['_ajax_nonce'] ?? ''));
        foreach (['bulk-comments', 'delete-comment_' . $id, 'approve-comment_' . $id, 'unapprove-comment_' . $id] as $nonce_action) {
            if (wp_verify_nonce($nonce, $nonce_action)) { return true; }
        }
        return false;
    }

    public function transition(string $new, string $old, $comment): void {
        if ($new === $old) { return; }
        $id = (int) $comment->comment_ID;
        if (in_array($new, ['trash', 'deleted'], true)) { $this->record($id, 'withdrawn', 'automatic'); return; }
        $label = $new === 'spam' ? 'spam' : ($new === 'approved' ? 'ham' : '');
        if ($label && $this->manual_action($id, $label)) { $this->record($id, $label, 'manual'); }
    }

    public function not_spam(int $id): void {
        if ($this->manual_action($id, 'ham')) { $this->record($id, 'ham', 'manual'); }
    }

    public function edited(int $id): void {
        $comment = get_comment($id);
        $prediction = get_comment_meta($id, '_spamapi_result', true);
        if ($prediction && (!$comment || ($prediction['content_revision'] ?? '') !== hash('sha256', $comment->comment_content))) { delete_comment_meta($id, '_spamapi_result'); }
        // Inspect training state under record's lock; a concurrent label may
        // still be committing when this hook starts.
        $this->record($id, 'withdrawn', 'edit');
    }

    public function deleted(int $id): void { $this->record($id, 'withdrawn', 'automatic'); }
    // Keep deleted-item watermarks until the server accepts their withdrawal.
    public function forget(int $id): void { $this->schedule(); }

    public static function minimize(string $content): string {
        $content = wp_check_invalid_utf8(substr($content, 0, 32768), true);
        $content = preg_replace('~<(script|style)\b[^>]*>.*?(?:</\1\s*>|$)~is', ' ', $content);
        $content = preg_replace('~<!--.*?(?:-->|$)|<![^>]*>~s', ' ', $content);
        // Mirror Go's href/src signals, including relative, unquoted, empty and
        // repeated attributes. Other markup separates text tokens as in Go.
        $content = preg_replace_callback('~<(/?)([a-z][a-z0-9:-]*)\b((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>~is', static function($tag) {
            $signals = ' ';
            if ($tag[1] === '' && in_array(strtolower($tag[2]), ['a', 'img'], true)) {
                preg_match_all('~(?:^|\s)([^\s/="\'<>]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>`]+)))?~i', $tag[3], $attributes, PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL);
                $seen = [];
                foreach ($attributes as $attribute) {
                    $name = strtolower($attribute[1]);
                    if (!in_array($name, ['href', 'src'], true) || isset($seen[$name])) { continue; }
                    $seen[$name] = true;
                    $signals .= self::minimize_url(html_entity_decode($attribute[2] ?? $attribute[3] ?? $attribute[4] ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                }
            }
            return $signals;
        }, $content);
        $content = html_entity_decode(wp_strip_all_tags($content), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $content = preg_replace_callback('~https?://[^\s<>"\']+~i', static function($m) { return self::minimize_url($m[0]); }, $content);
        $content = preg_replace('/[a-z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}/i', ' email ', $content);
        $content = preg_replace('/\b(?:\d{1,3}\.){3}\d{1,3}\b/', ' ip ', $content);
        $content = str_replace(['<', '>', '&'], ' ', $content);
        $content = trim(preg_replace('/\s+/u', ' ', $content));
        // WordPress' UTF-8 helper avoids cutting a multibyte character in half.
        return wp_check_invalid_utf8(substr($content, 0, 32768), true);
    }

    private static function minimize_url(string $value): string {
        $url = wp_parse_url($value);
        if (!is_array($url) || !in_array(strtolower($url['scheme'] ?? ''), ['http', 'https'], true) || empty($url['host']) || preg_match('/%(?![0-9a-f]{2})/i', $value)) { return ' url '; }
        $host = strtolower($url['host']);
        return filter_var(trim($host, '[]'), FILTER_VALIDATE_IP) ? ' ip ' : ' https://' . $host . '/ ';
    }

    /** A queued result means SQL COMMIT succeeded, never upstream ingestion. */
    public function record(int $id, string $label, string $provenance = 'manual'): array {
        if (!get_option('spamapi_training_enabled', false) || !$this->client->has_api_key()) { return ['status' => 'disabled']; }
        if ($provenance === 'manual' && !self::can_review($id)) { return ['status' => 'denied']; }
        if (!in_array($label, ['spam', 'ham', 'withdrawn'], true) || !in_array($provenance, ['manual', 'automatic', 'import', 'edit'], true)) { return ['status' => 'invalid']; }
        global $wpdb;
        $state = $wpdb->prefix . 'spamapi_training_state';
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        if ($wpdb->query('START TRANSACTION') === false) { return $this->queue_failure(); }
        if ($wpdb->get_var("SELECT revision FROM $state WHERE comment_id=0 FOR UPDATE") === null) { $wpdb->query('ROLLBACK'); return $this->queue_failure(); }
        if ($wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='spamapi_training_enabled'") !== '1') { $wpdb->query('ROLLBACK'); return ['status' => 'disabled']; }
        // A current locking read bypasses WordPress's object cache and any
        // earlier transaction snapshot. Edits either precede this capture or
        // wait for its commit, then observe the label and withdraw it.
        $comment = $wpdb->get_row($wpdb->prepare("SELECT comment_content FROM {$wpdb->comments} WHERE comment_ID=%d FOR UPDATE", $id));
        if ($wpdb->last_error) { $wpdb->query('ROLLBACK'); return $this->queue_failure(); }
        if (!$comment && $label !== 'withdrawn') { $wpdb->query('ROLLBACK'); return ['status' => 'missing']; }
        $previous = $wpdb->get_row($wpdb->prepare("SELECT * FROM $state WHERE comment_id=%d FOR UPDATE", $id), ARRAY_A);
        if ($wpdb->last_error) { $wpdb->query('ROLLBACK'); return $this->queue_failure(); }
        if (!$comment && !$previous) { $wpdb->query('ROLLBACK'); return ['status' => 'missing']; }
        $content_revision = $comment ? hash('sha256', $comment->comment_content) : $previous['content_revision'];
        if ($provenance === 'edit' && $label === 'withdrawn' && (!$previous || ($comment && $previous['content_revision'] === $content_revision))) { $wpdb->query('ROLLBACK'); return ['status' => 'unchanged']; }
        $fingerprint = hash('sha256', $content_revision . ':' . $label . ':' . $provenance);
        if ($previous && $previous['fingerprint'] === $fingerprint) { $wpdb->query('ROLLBACK'); return ['status' => 'duplicate']; }
        $evicted = false;
        if ($label === 'withdrawn') {
            $rows = $wpdb->get_results("SELECT * FROM $queue WHERE kind='event' ORDER BY id", ARRAY_A);
            $replace = array_filter($rows, static function($row) use ($previous) { return $previous && (json_decode($row['payload'], true)['item_id'] ?? '') === $previous['item_id']; });
            if (!$replace && (int) $wpdb->get_var("SELECT COUNT(*) FROM $queue") >= self::MAX_QUEUE) {
                foreach ($rows as $row) { if ((json_decode($row['payload'], true)['label'] ?? '') !== 'withdrawn') { $replace = [$row]; $evicted = true; break; } }
            }
            if (!$this->discard_locked_rows($replace)) { $wpdb->query('ROLLBACK'); return $this->queue_failure(); }
        }
        if ((int) $wpdb->get_var("SELECT COUNT(*) FROM $queue") >= self::MAX_QUEUE) { $wpdb->query('ROLLBACK'); return $this->queue_failure('queue_full'); }
        $item = $previous['item_id'] ?? wp_generate_uuid4();
        $revision = (int) ($previous['revision'] ?? 0) + 1;
        $prediction = get_comment_meta($id, '_spamapi_result', true);
        $event = [
            'event_id' => wp_generate_uuid4(), 'item_id' => $item, 'revision' => $revision,
            'content_revision' => $content_revision, 'label' => $label, 'provenance' => $provenance,
            'content' => $label === 'withdrawn' ? '' : self::minimize($comment->comment_content),
            'language' => get_bloginfo('language'), 'occurred_at' => (int) floor(microtime(true) * 1000000),
        ];
        // Edits invalidate prediction linkage as well as the previous label.
        if ($label !== 'withdrawn' && ($prediction['content_revision'] ?? '') === $content_revision && !empty($prediction['prediction_ref'])) { $event['prediction_ref'] = $prediction['prediction_ref']; }
        $ok = $wpdb->query($wpdb->prepare("INSERT INTO $state(comment_id,item_id,revision,fingerprint,content_revision) VALUES(%d,%s,%d,%s,%s) ON DUPLICATE KEY UPDATE revision=VALUES(revision),fingerprint=VALUES(fingerprint),content_revision=VALUES(content_revision)", $id, $item, $revision, $fingerprint, $content_revision));
        $ok = $ok !== false && $wpdb->insert($queue, ['event_id' => $event['event_id'], 'kind' => 'event', 'payload' => wp_json_encode($event), 'created_at' => time()]) !== false;
        if (!$ok || $wpdb->query('COMMIT') === false) { $wpdb->query('ROLLBACK'); return $this->queue_failure(); }
        if ($evicted) { $this->queue_failure('label_evicted_for_withdrawal'); }
        $this->schedule();
        return ['status' => 'queued', 'event_id' => $event['event_id']];
    }

    private function queue_failure(string $code = 'queue_storage_failed'): array {
        update_option('spamapi_training_failure', $code, false);
        return ['status' => 'failed', 'error' => $code];
    }

    public static function can_review(int $id): bool {
        return current_user_can('moderate_comments') && current_user_can('edit_comment', $id);
    }

    /** Bind checks to an installation without enrolling it or uploading labels. */
    public function register_for_inference(): void {
        if (!$this->client->has_api_key() || get_option('spamapi_training_control_pending') || get_option('spamapi_training_enabled') || get_option('spamapi_training_server_version', 0)) { return; }
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        if ($wpdb->query('START TRANSACTION') === false) { $this->queue_failure(); return; }
        $wpdb->get_var("SELECT revision FROM {$wpdb->prefix}spamapi_training_state WHERE comment_id=0 FOR UPDATE");
        // Concurrent connection tests share one queued registration. Recheck
        // consent/version under the same lock used by cancellation and receipts.
        if ($wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='spamapi_training_enabled'") === '1' ||
            (int) $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='spamapi_training_server_version'") > 0 ||
            (int) $wpdb->get_var("SELECT COUNT(*) FROM $queue WHERE kind='control'") > 0) { $wpdb->query('ROLLBACK'); return; }
        if ((int) $wpdb->get_var("SELECT COUNT(*) FROM $queue") >= self::MAX_QUEUE) { $wpdb->query('ROLLBACK'); $this->queue_failure('queue_full'); return; }
        $payload = ['enabled' => false, 'policy_version' => self::POLICY, 'site' => get_bloginfo('url'), 'expected_version' => 0];
        if ($wpdb->insert($queue, ['event_id' => wp_generate_uuid4(), 'kind' => 'control', 'payload' => wp_json_encode($payload), 'created_at' => time()]) === false || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK'); $this->queue_failure(); return;
        }
        $this->schedule();
    }

    private function invalidate_worker(): void {
        global $wpdb;
        $wpdb->query("UPDATE {$wpdb->prefix}spamapi_training_state SET lease_until=0,lease_token='' WHERE comment_id=0");
    }

    private function owns_lease(string $lease): bool {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}spamapi_training_state WHERE comment_id=0 AND lease_token=%s AND lease_until>=%d", $lease, time())) === 1;
    }

    /** Serialize local receipt writes against configuration cancellation. */
    private function apply_receipt(string $lease, callable $apply): bool {
        global $wpdb;
        if ($wpdb->query('START TRANSACTION') === false) { $this->queue_failure(); return false; }
        $wpdb->get_var("SELECT revision FROM {$wpdb->prefix}spamapi_training_state WHERE comment_id=0 FOR UPDATE");
        if (!$this->owns_lease($lease)) { $wpdb->query('ROLLBACK'); return false; }
        if (!$apply() || $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            foreach (['spamapi_training_server_version', 'spamapi_training_server_enabled', 'spamapi_training_server_site', 'spamapi_training_last_delivery'] as $option) { wp_cache_delete($option, 'options'); }
            $this->queue_failure(); return false;
        }
        return true;
    }

    /** Discarding is different from acknowledgement: permit a fresh review. */
    private function discard_events(array $rows): bool {
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        $state = $wpdb->prefix . 'spamapi_training_state';
        if (!$rows) { return true; }
        if ($wpdb->query('START TRANSACTION') === false) { return false; }
        $wpdb->get_var("SELECT revision FROM $state WHERE comment_id=0 FOR UPDATE");
        if (!$this->discard_locked_rows($rows)) { $wpdb->query('ROLLBACK'); return false; }
        if ($wpdb->query('COMMIT') === false) { $wpdb->query('ROLLBACK'); return false; }
        return true;
    }

    /** Caller holds the singleton state lock and owns the transaction. */
    private function discard_locked_rows(array $rows): bool {
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        $state = $wpdb->prefix . 'spamapi_training_state';
        foreach ($rows as $row) {
            $current = $wpdb->get_row($wpdb->prepare("SELECT payload FROM $queue WHERE id=%d FOR UPDATE", $row['id']), ARRAY_A);
            if (!$current) { continue; }
            $event = json_decode($current['payload'], true);
            if (isset($event['item_id'], $event['revision'])) {
                if ($wpdb->query($wpdb->prepare("UPDATE $state SET fingerprint='' WHERE item_id=%s AND revision=%d", $event['item_id'], $event['revision'])) === false) { return false; }
            }
            if ($wpdb->delete($queue, ['id' => $row['id']]) === false) { return false; }
        }
        return true;
    }

    public function participation_changed($old, $new, bool $replace = false): bool {
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        $state = $wpdb->prefix . 'spamapi_training_state';
        $payload = ['enabled' => (bool) $new, 'policy_version' => self::POLICY, 'site' => get_bloginfo('url')];
        if ($new && !$old && !$replace && get_option('spamapi_training_server_version', 0) && !get_option('spamapi_training_server_enabled') && $this->client->has_api_key() && !(int) $wpdb->get_var("SELECT COUNT(*) FROM $queue WHERE kind='control'")) {
            // Observe a restore's version at fresh consent, then persist it.
            // A delayed/pinned control must never refresh itself after a fence.
            $payload['expected_version'] = (int) get_option('spamapi_training_server_version');
            try {
                $status = $this->client->training_status(get_option('spamapi_installation_id'));
                if (isset($status['version'], $status['enabled'], $status['site']) && $status['enabled'] === false && $status['site'] === $payload['site']) { $payload['expected_version'] = (int) $status['version']; }
            } catch (SpamAPI_Exception $e) { /* Keep the observed local fence if status is unavailable. */ }
        }
        // This marker survives a failed transaction so a later worker can repair
        // the queue before sending any superseded enrollment or label.
        update_option('spamapi_training_control_pending', true, false);
        // Withdrawal supersedes queued enrollments, including blocked policies.
        // Its worker reconciles the current server generation before disabling.
        if (!$new || $replace) { $this->invalidate_worker(); }
        if ($wpdb->query('START TRANSACTION') === false) { $this->queue_failure(); $this->schedule(); return false; }
        $ok = $wpdb->query("SELECT revision FROM $state WHERE comment_id=0 FOR UPDATE") !== false;
        if ($new && $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name='spamapi_training_enabled'") !== '1') { $wpdb->query('ROLLBACK'); $this->schedule(); return false; }
        if (!$new || $replace) {
            $ok = $ok && $wpdb->query("DELETE FROM $queue") !== false;
            $ok = $ok && $wpdb->query("UPDATE $state SET fingerprint='' WHERE comment_id<>0") !== false;
        }
        if ((int) $wpdb->get_var("SELECT COUNT(*) FROM $queue") >= self::MAX_QUEUE) { $wpdb->query('ROLLBACK'); $this->queue_failure('queue_full'); $this->schedule(); return false; }
        $ok = $ok && $wpdb->insert($queue, ['event_id' => wp_generate_uuid4(), 'kind' => 'control', 'payload' => wp_json_encode($payload), 'created_at' => time()]) !== false;
        if (!$ok || $wpdb->query('COMMIT') === false) { $wpdb->query('ROLLBACK'); $this->queue_failure(); $this->schedule(); return false; }
        delete_option('spamapi_training_control_pending');
        $this->schedule();
        return true;
    }

    public function credentials_changed($old, $new): void {
        if ($old === $new) { return; }
        $this->invalidate_worker();
        delete_option('spamapi_training_policy');
        update_option('spamapi_training_enabled', false);
        // This request's client still has the previous connection. Try to retire
        // that identity before binding a fresh one to the changed credentials.
        $pending = (bool) get_option('spamapi_training_server_enabled');
        if (get_option('spamapi_training_server_version', 0) && $this->client->has_api_key()) {
            try {
                $status = $this->client->training_status(get_option('spamapi_installation_id'));
                if (!isset($status['site'], $status['version'], $status['policy_version'])) { throw new SpamAPI_Exception('Invalid participation receipt', 'invalid_receipt'); }
                $receipt = $this->client->training_participation(['installation_id' => get_option('spamapi_installation_id'), 'site' => $status['site'], 'enabled' => false, 'policy_version' => $status['policy_version'], 'expected_version' => (int) $status['version']]);
                $pending = !isset($receipt['enabled']) || $receipt['enabled'] !== false;
            } catch (SpamAPI_Exception $e) { $pending = true; }
        }
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->prefix}spamapi_training_queue");
        delete_option('spamapi_training_control_pending');
        update_option('spamapi_installation_id', wp_generate_uuid4(), false);
        update_option('spamapi_training_server_version', 0, false);
        update_option('spamapi_training_server_enabled', false, false);
        if ($pending) { $this->queue_failure('disconnected_withdrawal_pending_contact_previous_account_owner'); }
        else { delete_option('spamapi_training_failure'); }
    }

    private function schedule(): void {
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        $existing = wp_next_scheduled('spamapi_training_soon');
        $control = $wpdb->get_row("SELECT next_at FROM $queue WHERE kind='control' ORDER BY id LIMIT 1", ARRAY_A);
        $events = $wpdb->get_row("SELECT COUNT(*) AS total,MIN(next_at) AS due,MIN(created_at) AS oldest FROM $queue WHERE kind='event'", ARRAY_A);
        $due = $control ? (int) $control['next_at'] : null;
        if (get_option('spamapi_training_control_pending') || ((int) ($events['total'] ?? 0) < self::MAX_QUEUE && get_option('spamapi_training_enabled') && $this->unqueued_deleted_items())) { $due = $due === null ? time() + 10 : min($due, time() + 10); }
        if ((int) ($events['total'] ?? 0) > 0) {
            if ($due === null) { $due = (int) $events['due']; }
            // Parked events still need their text removed at the age limit.
            $due = min($due, (int) $events['oldest'] + self::MAX_AGE + 1);
        }
        if ($due === null || !$this->client->has_api_key()) {
            if ($existing) { wp_unschedule_event($existing, 'spamapi_training_soon'); }
            return;
        }
        $due = max(time() + 10, $due);
        if ($existing && $existing <= $due && $due <= time() + 10) { return; }
        if ($existing === $due) { return; }
        if ($existing) { wp_unschedule_event($existing, 'spamapi_training_soon'); }
        if (is_wp_error(wp_schedule_single_event($due, 'spamapi_training_soon', [], true))) { $this->queue_failure('schedule_failed'); }
    }

    private function reconcile_site_binding(): void {
        $acknowledged_site = get_option('spamapi_training_server_site', '');
        if (!$this->client->has_api_key() || !get_option('spamapi_training_server_version', 0) || $acknowledged_site === get_bloginfo('url')) { return; }
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        $pending = $wpdb->get_var("SELECT payload FROM $queue WHERE kind='control' ORDER BY id DESC LIMIT 1");
        if (!$pending || (json_decode($pending, true)['site'] ?? '') !== get_bloginfo('url')) { $this->site_changed($acknowledged_site, get_bloginfo('url')); }
    }

    public function site_changed($old, $new): void {
        if ($old === $new || !get_option('spamapi_training_server_version', 0)) { return; }
        // Old-context labels/predictions cannot move to a different site. Keep
        // the installation identity, and rebind it through the authenticated CAS.
        $enabled = (bool) get_option('spamapi_training_enabled', false);
        $this->participation_changed($enabled, $enabled, true);
    }

    private function unqueued_deleted_items(): array {
        global $wpdb;
        // At most 1,000 can already be queued; examine 20 more to avoid starving
        // an unqueued deletion behind rows whose delivery has been deferred.
        $rows = $wpdb->get_results("SELECT s.* FROM {$wpdb->prefix}spamapi_training_state s LEFT JOIN {$wpdb->comments} c ON c.comment_ID=s.comment_id WHERE s.comment_id<>0 AND c.comment_ID IS NULL ORDER BY s.comment_id LIMIT 1020", ARRAY_A);
        if (!$rows) { return []; }
        $pending = [];
        foreach ($wpdb->get_col("SELECT payload FROM {$wpdb->prefix}spamapi_training_queue WHERE kind='event'") as $payload) {
            $event = json_decode($payload, true);
            if (($event['label'] ?? '') === 'withdrawn') { $pending[$event['item_id'] . ':' . $event['revision']] = true; }
        }
        return array_slice(array_filter($rows, static function($row) use ($pending) { return !isset($pending[$row['item_id'] . ':' . $row['revision']]); }), 0, 20);
    }

    /** Recover retractions after deletion or a failed local queue write. */
    private function retry_deleted(): bool {
        global $wpdb;
        foreach ($this->unqueued_deleted_items() as $row) {
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}spamapi_training_state SET fingerprint='' WHERE comment_id=%d AND revision=%d", $row['comment_id'], $row['revision']));
            $result = $this->record((int) $row['comment_id'], 'withdrawn', 'automatic');
            if (!in_array($result['status'], ['queued', 'duplicate'], true)) {
                // Never upload an unsent label for a comment already deleted,
                // even if its replacement withdrawal could not be written.
                $labels = array_filter($wpdb->get_results("SELECT * FROM {$wpdb->prefix}spamapi_training_queue WHERE kind='event'", ARRAY_A), static function($queued) use ($row) {
                    $event = json_decode($queued['payload'], true);
                    return ($event['item_id'] ?? '') === $row['item_id'] && ($event['label'] ?? '') !== 'withdrawn';
                });
                if (!$this->discard_events($labels)) { $this->queue_failure(); return false; }
            }
        }
        return true;
    }

    public function drain(): void {
        global $wpdb;
        $state = $wpdb->prefix . 'spamapi_training_state'; $queue = $wpdb->prefix . 'spamapi_training_queue';
        $now = time();
        if (!$this->client->has_api_key()) {
            if (!$this->discard_events($wpdb->get_results("SELECT * FROM $queue WHERE kind='event'", ARRAY_A))) { $this->queue_failure(); }
            $this->schedule(); return;
        }
        // Filters may be installed after plugins_loaded. Reconcile again before
        // delivering any label through an acknowledged installation binding.
        $this->reconcile_site_binding();
        if (get_option('spamapi_training_control_pending')) {
            $enabled = (bool) get_option('spamapi_training_enabled', false);
            if (!$this->participation_changed($enabled, $enabled, true)) { return; }
        }
        $lease = wp_generate_uuid4();
        if ($wpdb->query($wpdb->prepare("UPDATE $state SET lease_until=%d,lease_token=%s WHERE comment_id=0 AND lease_until<%d", $now + 60, $lease, $now)) !== 1) { $this->schedule(); return; }
        try {
            // Expired events cannot be acknowledged as ingested. Remove text and
            // retain an aggregate failure visible in settings.
            // Clear only fingerprints whose current revision is expiring; newer queued reviews remain deduplicated.
            $expired = $wpdb->get_results($wpdb->prepare("SELECT * FROM $queue WHERE kind='event' AND created_at<%d", $now - self::MAX_AGE), ARRAY_A);
            if (!$this->discard_events($expired)) { $this->queue_failure(); return; }
            if ($expired) { $this->queue_failure('events_expired'); }
            $control = $wpdb->get_row("SELECT * FROM $queue WHERE kind='control' ORDER BY id LIMIT 1", ARRAY_A);
            if ($control) {
                if ((int) $control['next_at'] > $now) { return; }
                $p = json_decode($control['payload'], true);
                if ($p['enabled'] && get_option('spamapi_training_server_version', 0) && $p['site'] !== get_option('spamapi_training_server_site', '')) {
                    $status = $this->client->training_status(get_option('spamapi_installation_id'));
                    if (!isset($status['version'], $status['enabled'], $status['site'])) { throw new SpamAPI_Exception('Invalid participation receipt', 'invalid_receipt'); }
                    // A delayed site-change job must not re-enroll a withdrawn
                    // installation or overwrite a different completed rebind.
                    if ($status['enabled'] !== true || !in_array($status['site'], [get_option('spamapi_training_server_site', ''), $p['site']], true)) {
                        throw new SpamAPI_Exception('Participation changed; re-enable explicitly', 'contribution_disabled', 403);
                    }
                    $p['expected_version'] = (int) $status['version'];
                }
                // Fresh inference registration pins zero for exact retries;
                // withdrawals reconcile the latest remote generation instead.
                if (!$p['enabled'] && !isset($p['expected_version'])) {
                    try {
                        $status = $this->client->training_status(get_option('spamapi_installation_id'));
                        if (!isset($status['version'], $status['site'])) { throw new SpamAPI_Exception('Invalid participation receipt', 'invalid_receipt'); }
                        $p['expected_version'] = (int) $status['version'];
                    } catch (SpamAPI_Exception $e) {
                        // A never-registered installation can be created disabled.
                        if ($e->get_status_code() !== 403) { throw $e; }
                        $p['expected_version'] = 0;
                    }
                }
                if (!isset($p['expected_version'])) { $p['expected_version'] = (int) get_option('spamapi_training_server_version', 0); }
                // Persist every resolved generation before HTTP. A lost response
                // must retry the same CAS instead of advancing another fence.
                if (!$this->apply_receipt($lease, static function() use ($wpdb, $queue, $control, $p) {
                    return $wpdb->update($queue, ['payload' => wp_json_encode($p)], ['id' => $control['id']]) !== false;
                })) { return; }
                $p['installation_id'] = get_option('spamapi_installation_id');
                $result = $this->client->training_participation($p);
                if (!$this->owns_lease($lease)) { return; }
                if (!isset($result['version']) || $result['enabled'] !== $p['enabled']) { throw new SpamAPI_Exception('Invalid participation receipt', 'invalid_receipt'); }
                if (!$this->apply_receipt($lease, static function() use ($wpdb, $state, $queue, $control, $p, $result) {
                    update_option('spamapi_training_server_version', (int) $result['version'], false);
                    update_option('spamapi_training_server_enabled', $result['enabled'], false);
                    update_option('spamapi_training_server_site', $result['site'] ?? $p['site'], false);
                    if (!$result['enabled'] && $wpdb->query("DELETE FROM $state WHERE comment_id<>0 AND NOT EXISTS(SELECT 1 FROM {$wpdb->comments} c WHERE c.comment_ID=$state.comment_id)") === false) { return false; }
                    return $wpdb->delete($queue, ['id' => $control['id']]) !== false;
                })) { return; }
                // A home change before the first acknowledgement has no owned
                // version to rebind yet. Reconcile it now, after exact retries
                // of that initial registration/enrollment have completed.
                $acknowledged_site = $result['site'] ?? $p['site'];
                if ($acknowledged_site !== get_bloginfo('url')) { $this->site_changed($acknowledged_site, get_bloginfo('url')); }
                $this->schedule(); return;
            }
            if (!get_option('spamapi_training_enabled') || !get_option('spamapi_training_server_enabled')) {
                if (!$this->discard_events($wpdb->get_results("SELECT * FROM $queue WHERE kind='event'", ARRAY_A))) { $this->queue_failure(); }
                return;
            }
            if (!$this->retry_deleted()) { return; }
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $queue WHERE kind='event' AND next_at<=%d ORDER BY id", $now), ARRAY_A);
            if (!$rows) { return; }
            // Deliver withdrawals separately so paused collection cannot reject
            // a mixed batch and prevent removing previously accepted sources.
            $withdrawals = array_filter($rows, static function($row) { return (json_decode($row['payload'], true)['label'] ?? '') === 'withdrawn'; });
            $rows = array_slice($withdrawals ?: $rows, 0, 20);
            $events = []; $selected = []; $bytes = 0;
            foreach ($rows as $row) { if ($bytes + strlen($row['payload']) > 220000) { break; } $bytes += strlen($row['payload']); $events[] = json_decode($row['payload'], true); $selected[] = $row; }
            $result = $this->client->training_contributions([
                'schema_version' => 1, 'installation_id' => get_option('spamapi_installation_id'),
                'policy_version' => self::POLICY, 'participation_version' => (int) get_option('spamapi_training_server_version'),
                'minimizer_version' => 'wordpress-min-v1', 'events' => $events,
            ]);
            if (!$this->owns_lease($lease)) { return; }
            $receipts = [];
            if (($result['status'] ?? '') === 'durable') { foreach (($result['receipts'] ?? []) as $receipt) { if (in_array($receipt['status'] ?? '', ['accepted', 'duplicate', 'stale'], true)) { $receipts[$receipt['event_id']] = $receipt['status']; } } }
            if (!$this->apply_receipt($lease, static function() use ($wpdb, $state, $queue, $selected, $receipts, $now) {
                foreach ($selected as $row) {
                    if (!isset($receipts[$row['event_id']])) { continue; }
                    if ($wpdb->delete($queue, ['event_id' => $row['event_id']]) === false) { return false; }
                    $event = json_decode($row['payload'], true);
                    if (($event['label'] ?? '') === 'withdrawn') {
                        $action = $receipts[$row['event_id']] === 'accepted' ? "DELETE FROM $state" : "UPDATE $state SET fingerprint=''";
                        if ($wpdb->query($wpdb->prepare("$action WHERE item_id=%s AND revision=%d AND comment_id<>0 AND NOT EXISTS(SELECT 1 FROM {$wpdb->comments} c WHERE c.comment_ID=$state.comment_id)", $event['item_id'], $event['revision'])) === false) { return false; }
                    }
                }
                if ($receipts) { update_option('spamapi_training_last_delivery', $now, false); }
                return true;
            })) { return; }
            foreach ($selected as $row) { if (!isset($receipts[$row['event_id']])) { $this->retry($row, 0, 'invalid_receipt'); } }
            $this->schedule();
        } catch (SpamAPI_Exception $e) {
            if (!$this->owns_lease($lease)) { return; }
            // HTTP bodies, content and credentials never enter the failure UI/log.
            if (empty($control) && $e->get_status_code() >= 400 && $e->get_status_code() < 500 && !in_array($e->get_status_code(), [401, 403, 408, 429], true)) {
                $this->queue_failure($this->discard_events($selected ?? []) ? 'delivery_rejected_' . sanitize_key($e->get_error_code()) : 'queue_storage_failed');
            } elseif ($e->get_status_code() === 403 && $e->get_error_code() === 'contribution_disabled' && empty($control)) {
                $discard = [];
                foreach ($wpdb->get_results("SELECT * FROM $queue WHERE kind='event'", ARRAY_A) as $row) {
                    if ((json_decode($row['payload'], true)['label'] ?? '') !== 'withdrawn') { $discard[] = $row; }
                    else { $wpdb->update($queue, ['next_at' => 0], ['id' => $row['id']]); }
                }
                $this->queue_failure($this->discard_events($discard) ? 'collection_paused_withdrawals_pending' : 'queue_storage_failed');
            } elseif (!empty($control) && isset($p) && !$p['enabled'] && $e->get_status_code() === 409) {
                // Only a confirmed conflict permits a withdrawal to observe a
                // newer generation. Enrollments remain pinned to consent.
                unset($p['expected_version']);
                if (!$this->apply_receipt($lease, static function() use ($wpdb, $queue, $control, $p) {
                    return $wpdb->update($queue, ['payload' => wp_json_encode($p)], ['id' => $control['id']]) !== false;
                })) { return; }
                $this->retry($control, $e->get_retry_after(), $e->get_error_code());
            } elseif (in_array($e->get_status_code(), [401, 403], true)) {
                if ($control) { $this->retry($control, $e->get_retry_after(), $e->get_error_code()); }
                $this->queue_failure($this->discard_events($wpdb->get_results("SELECT * FROM $queue WHERE kind='event'", ARRAY_A)) ? 'credentials_or_participation_denied' : 'queue_storage_failed');
            } else { foreach ($control ? [$control] : ($selected ?? []) as $row) { $this->retry($row, $e->get_retry_after(), $e->get_error_code(), $e->get_status_code() !== 429); } }
        } finally {
            $wpdb->query($wpdb->prepare("UPDATE $state SET lease_until=0,lease_token='' WHERE comment_id=0 AND lease_token=%s", $lease));
            $this->schedule();
        }
    }

    private function retry(array $row, int $retry_after, string $code, bool $counts_failure = true): void {
        global $wpdb;
        $attempt = (int) $row['attempts'] + ($counts_failure ? 1 : 0);
        $delay = max($retry_after, min(21600, 30 * (2 ** min(10, $attempt))) + wp_rand(0, 30));
        // Control withdrawals keep retrying without storing visitor text.
        if ($row['kind'] === 'event' && $counts_failure && $attempt >= 12) { $wpdb->update($wpdb->prefix . 'spamapi_training_queue', ['attempts' => $attempt, 'next_at' => PHP_INT_MAX], ['id' => $row['id']]); $code = 'exhausted_retry_required'; }
        else { $wpdb->update($wpdb->prefix . 'spamapi_training_queue', ['attempts' => $attempt, 'next_at' => time() + min(86400, $delay)], ['id' => $row['id']]); }
        $this->queue_failure('delivery_' . sanitize_key($code));
        $this->schedule();
    }

    public static function status(): array {
        global $wpdb;
        $queue = $wpdb->prefix . 'spamapi_training_queue';
        return ['pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $queue"), 'oldest' => (int) $wpdb->get_var("SELECT MIN(created_at) FROM $queue"), 'failure' => get_option('spamapi_training_failure', ''), 'server_enabled' => (bool) get_option('spamapi_training_server_enabled', false)];
    }

    public function retry_failed(): void {
        global $wpdb;
        $wpdb->query("UPDATE {$wpdb->prefix}spamapi_training_queue SET next_at=0,attempts=0");
        delete_option('spamapi_training_failure');
        $this->drain();
    }

    /** Explicit preview/confirm; stable numeric cursor, never activation backfill. */
    public function backfill(array $args, array $flags): void {
        global $wpdb;
        $label = $flags['label'] ?? '';
        if (!in_array($label, ['spam', 'ham'], true)) { WP_CLI::error('--label=spam|ham is required'); }
        $after = absint($flags['after'] ?? 0); $limit = min(100, max(1, absint($flags['limit'] ?? 100)));
        $reviewed = isset($flags['reviewed-ids']);
        if ($reviewed) {
            $ids = array_slice(array_filter(array_map('absint', explode(',', $flags['reviewed-ids']))), 0, $limit);
        } else {
            $status = $label === 'spam' ? 'spam' : '1';
            $ids = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT comment_ID FROM {$wpdb->comments} WHERE comment_ID>%d AND comment_approved=%s ORDER BY comment_ID LIMIT %d", $after, $status, $limit)));
        }
        $out = ['count' => count($ids), 'after' => $after, 'next_cursor' => $ids ? max($ids) : $after, 'provenance' => $reviewed ? 'manual' : 'import', 'queued' => 0];
        if (isset($flags['confirm'])) {
            foreach ($ids as $id) {
                $receipt = $this->record($id, $label, $reviewed ? 'manual' : 'import');
                if (in_array($receipt['status'], ['queued', 'duplicate'], true)) { $out['queued']++; }
                else { $out['failed_at'] = $id; $out['next_cursor'] = $id - 1; break; }
            }
        }
        WP_CLI::line(wp_json_encode($out));
    }

    public static function disconnect(): void {
        global $wpdb;
        update_option('spamapi_training_enabled', false);
        $wpdb->delete($wpdb->prefix . 'spamapi_training_queue', ['kind' => 'event']);
        $id = get_option('spamapi_installation_id');
        if (!$id || !get_option('spamapi_api_key')) { return; }
        $client = new SpamAPI_Client(get_option('spamapi_api_key'), get_option('spamapi_api_url', defined('SPAMAPI_API_URL') ? SPAMAPI_API_URL : 'https://api.spamapi.de/api/v1'));
        try {
            $status = $client->training_status($id);
            $client->training_participation(['installation_id' => $id, 'site' => $status['site'], 'enabled' => false, 'policy_version' => $status['policy_version'], 'expected_version' => (int) $status['version']]);
            update_option('spamapi_training_server_enabled', false, false);
        } catch (SpamAPI_Exception $e) { update_option('spamapi_training_failure', 'withdrawal_pending_contact_account_owner', false); }
    }
}
