<?php
/**
 * SpamAPI admin settings.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_Admin {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Settings page slug.
     *
     * @var string
     */
    private string $page_slug = 'spamapi-settings';

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
    }

    /**
     * Add admin menu.
     */
    public function add_menu(): void {
        add_options_page(
            __('SpamAPI Settings', 'spamapi-antispam'),
            __('SpamAPI', 'spamapi-antispam'),
            'manage_options',
            $this->page_slug,
            [$this, 'render_settings_page']
        );
    }

    /**
     * Register settings.
     */
    public function register_settings(): void {
        // Register settings
        register_setting('spamapi_settings', 'spamapi_enabled', [
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);

        register_setting('spamapi_settings', 'spamapi_api_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);

        register_setting('spamapi_settings', 'spamapi_api_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => SPAMAPI_API_URL,
        ]);

        register_setting('spamapi_settings', 'spamapi_strictness', [
            'type' => 'string',
            'sanitize_callback' => [$this, 'sanitize_strictness'],
            'default' => 'balanced',
        ]);

        // Add settings sections
        add_settings_section(
            'spamapi_main',
            __('API Configuration', 'spamapi-antispam'),
            [$this, 'render_main_section'],
            $this->page_slug
        );

        add_settings_section(
            'spamapi_behavior',
            __('Behavior Settings', 'spamapi-antispam'),
            null,
            $this->page_slug
        );

        // Add settings fields
        add_settings_field(
            'spamapi_enabled',
            __('Enable SpamAPI', 'spamapi-antispam'),
            [$this, 'render_enabled_field'],
            $this->page_slug,
            'spamapi_main'
        );

        add_settings_field(
            'spamapi_api_key',
            __('API Key', 'spamapi-antispam'),
            [$this, 'render_api_key_field'],
            $this->page_slug,
            'spamapi_main'
        );

        add_settings_field(
            'spamapi_api_url',
            __('API URL', 'spamapi-antispam'),
            [$this, 'render_api_url_field'],
            $this->page_slug,
            'spamapi_main'
        );

        add_settings_field(
            'spamapi_strictness',
            __('Strictness Level', 'spamapi-antispam'),
            [$this, 'render_strictness_field'],
            $this->page_slug,
            'spamapi_behavior'
        );
    }

    /**
     * Enqueue admin scripts and styles.
     *
     * @param string $hook_suffix Admin page hook suffix.
     */
    public function enqueue_scripts(string $hook_suffix): void {
        if ($hook_suffix !== 'settings_page_' . $this->page_slug) {
            return;
        }

        wp_enqueue_style(
            'spamapi-admin',
            SPAMAPI_PLUGIN_URL . 'assets/css/admin.css',
            [],
            SPAMAPI_VERSION
        );

        wp_enqueue_script(
            'spamapi-admin',
            SPAMAPI_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            SPAMAPI_VERSION,
            true
        );

        wp_localize_script('spamapi-admin', 'spamapiAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => get_rest_url(null, 'spamapi/v1/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'nonce' => wp_create_nonce('spamapi_admin'),
            'strings' => [
                'testing' => __('Testing connection...', 'spamapi-antispam'),
                'success' => __('Connection successful!', 'spamapi-antispam'),
                'error' => __('Connection failed:', 'spamapi-antispam'),
            ],
        ]);
    }

    /**
     * Add plugin action links.
     *
     * @param array $links Existing links.
     * @return array Modified links.
     */
    public function add_action_links(array $links): array {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            admin_url('options-general.php?page=' . $this->page_slug),
            __('Settings', 'spamapi-antispam')
        );
        array_unshift($links, $settings_link);
        return $links;
    }

    /**
     * Render settings page.
     */
    public function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Check for settings saved message
        if (isset($_GET['settings-updated'])) {
            add_settings_error(
                'spamapi_messages',
                'spamapi_message',
                __('Settings saved.', 'spamapi-antispam'),
                'updated'
            );
        }

        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <?php settings_errors('spamapi_messages'); ?>

            <form action="options.php" method="post">
                <?php
                settings_fields('spamapi_settings');
                do_settings_sections($this->page_slug);
                submit_button(__('Save Settings', 'spamapi-antispam'));
                ?>
            </form>

            <?php $this->render_usage_stats(); ?>
        </div>
        <?php
    }

    /**
     * Render main section description.
     */
    public function render_main_section(): void {
        echo '<p>' . esc_html__(
            'Configure your SpamAPI connection. You can get an API key from your SpamAPI dashboard.',
            'spamapi-antispam'
        ) . '</p>';
    }

    /**
     * Render enabled field.
     */
    public function render_enabled_field(): void {
        $enabled = get_option('spamapi_enabled', false);
        ?>
        <label>
            <input type="checkbox" name="spamapi_enabled" value="1" <?php checked($enabled); ?>>
            <?php esc_html_e('Enable spam protection', 'spamapi-antispam'); ?>
        </label>
        <p class="description">
            <?php esc_html_e('Check this to enable SpamAPI spam protection for your site.', 'spamapi-antispam'); ?>
        </p>
        <?php
    }

    /**
     * Render API key field.
     */
    public function render_api_key_field(): void {
        $api_key = get_option('spamapi_api_key', '');
        ?>
        <input type="text"
               name="spamapi_api_key"
               value="<?php echo esc_attr($api_key); ?>"
               class="regular-text"
               autocomplete="off">
        <button type="button" class="button" id="spamapi-test-connection">
            <?php esc_html_e('Test Connection', 'spamapi-antispam'); ?>
        </button>
        <span id="spamapi-test-result"></span>
        <p class="description">
            <?php
            printf(
                /* translators: %s: Dashboard URL */
                esc_html__('Enter your SpamAPI API key. Get one from your %s.', 'spamapi-antispam'),
                '<a href="https://spamapi.de/dashboard/keys" target="_blank" rel="noopener noreferrer">' .
                esc_html__('SpamAPI dashboard', 'spamapi-antispam') . '</a>'
            );
            ?>
        </p>
        <?php
    }

    /**
     * Render API URL field.
     */
    public function render_api_url_field(): void {
        $api_url = get_option('spamapi_api_url', SPAMAPI_API_URL);
        ?>
        <input type="url"
               name="spamapi_api_url"
               value="<?php echo esc_url($api_url); ?>"
               class="regular-text">
        <p class="description">
            <?php esc_html_e('API endpoint URL. Only change this if using a self-hosted instance.', 'spamapi-antispam'); ?>
        </p>
        <?php
    }

    /**
     * Render strictness field.
     */
    public function render_strictness_field(): void {
        $strictness = get_option('spamapi_strictness', 'balanced');
        $options = [
            'lenient' => __('Lenient - Only block obvious spam', 'spamapi-antispam'),
            'balanced' => __('Balanced - Block likely spam (recommended)', 'spamapi-antispam'),
            'strict' => __('Strict - Block anything suspicious', 'spamapi-antispam'),
        ];
        ?>
        <select name="spamapi_strictness">
            <?php foreach ($options as $value => $label) : ?>
                <option value="<?php echo esc_attr($value); ?>" <?php selected($strictness, $value); ?>>
                    <?php echo esc_html($label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <p class="description">
            <?php esc_html_e('Higher strictness may block more legitimate content.', 'spamapi-antispam'); ?>
        </p>
        <?php
    }

    /**
     * Render usage statistics section.
     */
    private function render_usage_stats(): void {
        if (!$this->client->has_api_key()) {
            return;
        }

        try {
            $usage = $this->client->get_usage();
        } catch (SpamAPI_Exception $e) {
            return;
        }

        $percentage = floatval($usage['percentage'] ?? 0);
        $bar_class = $percentage >= 90 ? 'spamapi-usage-danger' : ($percentage >= 75 ? 'spamapi-usage-warning' : '');
        ?>
        <div class="spamapi-usage-stats">
            <h2><?php esc_html_e('Usage This Month', 'spamapi-antispam'); ?></h2>
            <div class="spamapi-usage-bar-container">
                <div class="spamapi-usage-bar <?php echo esc_attr($bar_class); ?>"
                     style="width: <?php echo esc_attr(min($percentage, 100)); ?>%">
                </div>
            </div>
            <p>
                <?php
                printf(
                    /* translators: 1: Used calls, 2: Total limit, 3: Percentage */
                    esc_html__('%1$s of %2$s API calls used (%3$s%%)', 'spamapi-antispam'),
                    number_format_i18n($usage['used'] ?? 0),
                    number_format_i18n($usage['limit'] ?? 0),
                    $usage['percentage'] ?? '0'
                );
                ?>
            </p>
            <?php if (isset($usage['resets_at'])) : ?>
                <p class="description">
                    <?php
                    $reset_date = date_i18n(
                        get_option('date_format'),
                        strtotime($usage['resets_at'])
                    );
                    printf(
                        /* translators: %s: Reset date */
                        esc_html__('Resets on %s', 'spamapi-antispam'),
                        $reset_date
                    );
                    ?>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Sanitize strictness option.
     *
     * @param string $value Input value.
     * @return string Sanitized value.
     */
    public function sanitize_strictness(string $value): string {
        $valid = ['lenient', 'balanced', 'strict'];
        return in_array($value, $valid, true) ? $value : 'balanced';
    }
}
