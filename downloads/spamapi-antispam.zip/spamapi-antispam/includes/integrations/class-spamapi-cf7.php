<?php
/**
 * SpamAPI Contact Form 7 integration.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_CF7 {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks(): void {
        // Hook into CF7 spam check
        add_filter('wpcf7_spam', [$this, 'check_spam'], 10, 2);
    }

    /**
     * Check form submission for spam.
     *
     * @param bool $spam Current spam status.
     * @param WPCF7_Submission $submission Form submission.
     * @return bool Modified spam status.
     */
    public function check_spam(bool $spam, WPCF7_Submission $submission): bool {
        // Already marked as spam
        if ($spam) {
            return $spam;
        }

        $posted_data = $submission->get_posted_data();
        $form = $submission->get_contact_form();

        // Extract author/email/content based on form tags
        $data = $this->extract_form_data($posted_data, $form);

        try {
            $result = $this->client->check($data);

            $threshold = SpamAPI_Utils::get_threshold();

            if ($result['is_spam'] && $result['score'] >= $threshold) {
                return true; // Mark as spam
            }
        } catch (SpamAPI_Exception $e) {
            error_log('SpamAPI Error: ' . $e->getMessage());
        }

        return $spam;
    }

    /**
     * Extract form data for spam check.
     *
     * @param array $posted_data Posted form data.
     * @param WPCF7_ContactForm $form Contact form instance.
     * @return array Extracted data.
     */
    private function extract_form_data(array $posted_data, WPCF7_ContactForm $form): array {
        $tags = $form->scan_form_tags();

        $author = '';
        $email = '';
        $content_parts = [];

        foreach ($tags as $tag) {
            $name = $tag->name;
            if (!isset($posted_data[$name])) {
                continue;
            }

            $value = $posted_data[$name];
            if (is_array($value)) {
                $value = implode(', ', $value);
            }

            // Check for spamapi: option (similar to akismet:)
            $options = $tag->options;
            foreach ($options as $option) {
                if (strpos($option, 'spamapi:') === 0) {
                    $type = substr($option, 8);
                    switch ($type) {
                        case 'author':
                            $author = $value;
                            break;
                        case 'author_email':
                            $email = $value;
                            break;
                    }
                }
            }

            // Also detect by basetype
            if (empty($author) && $tag->basetype === 'text' && strpos($name, 'name') !== false) {
                $author = $value;
            }
            if (empty($email) && $tag->basetype === 'email') {
                $email = $value;
            }
            if ($tag->basetype === 'textarea') {
                $content_parts[] = $value;
            }
        }

        return [
            'user_ip' => SpamAPI_Utils::get_ip_address(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'comment_type' => 'contact-form',
            'comment_author' => $author,
            'comment_author_email' => $email,
            'comment_content' => implode("\n\n", $content_parts),
            'blog_lang' => get_bloginfo('language'),
        ];
    }

}
