<?php
/**
 * SpamAPI Gravity Forms integration.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_Gravity_Forms {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks(): void {
        add_filter('gform_entry_is_spam', [$this, 'check_spam'], 10, 3);
    }

    /**
     * Check form entry for spam.
     *
     * @param bool $is_spam Current spam status.
     * @param array $form Form configuration.
     * @param array $entry Form entry data.
     * @return bool Modified spam status.
     */
    public function check_spam(bool $is_spam, array $form, array $entry): bool {
        if ($is_spam) {
            return $is_spam;
        }

        $data = $this->extract_entry_data($form, $entry);

        try {
            $result = $this->client->check($data);

            $threshold = SpamAPI_Utils::get_threshold();

            if ($result['is_spam'] && $result['score'] >= $threshold) {
                return true;
            }
        } catch (SpamAPI_Exception $e) {
            error_log('SpamAPI Gravity Forms Error: ' . $e->getMessage());
        }

        return $is_spam;
    }

    /**
     * Extract entry data for spam check.
     *
     * @param array $form Form configuration.
     * @param array $entry Form entry.
     * @return array Extracted data.
     */
    private function extract_entry_data(array $form, array $entry): array {
        $author = '';
        $email = '';
        $content_parts = [];

        foreach ($form['fields'] as $field) {
            $field_id = $field->id;
            $value = rgar($entry, $field_id);

            switch ($field->type) {
                case 'name':
                    // Handle name field (may have multiple inputs)
                    if (is_array($field->inputs)) {
                        $name_parts = [];
                        foreach ($field->inputs as $input) {
                            $input_value = rgar($entry, (string) $input['id']);
                            if (!empty($input_value)) {
                                $name_parts[] = $input_value;
                            }
                        }
                        $author = implode(' ', $name_parts);
                    } else {
                        $author = $value;
                    }
                    break;

                case 'email':
                    $email = $value;
                    break;

                case 'textarea':
                case 'text':
                case 'post_content':
                    if (!empty($value)) {
                        $content_parts[] = $value;
                    }
                    break;
            }
        }

        return [
            'user_ip' => $entry['ip'] ?? SpamAPI_Utils::get_ip_address(),
            'user_agent' => $entry['user_agent'] ?? ($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'comment_type' => 'contact-form',
            'comment_author' => $author,
            'comment_author_email' => $email,
            'comment_content' => implode("\n\n", $content_parts),
            'blog_lang' => get_bloginfo('language'),
        ];
    }

}
