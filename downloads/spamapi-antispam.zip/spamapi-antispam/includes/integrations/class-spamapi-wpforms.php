<?php
/**
 * SpamAPI WPForms integration.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_WPForms {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks(): void {
        add_filter('wpforms_process_before_form_data', [$this, 'check_spam'], 10, 2);
    }

    /**
     * Check form submission for spam.
     *
     * @param array $form_data Form configuration.
     * @param array $entry Entry data.
     * @return array Modified form data (with errors if spam).
     */
    public function check_spam(array $form_data, array $entry): array {
        $data = $this->extract_entry_data($form_data, $entry);

        try {
            $result = $this->client->check($data);

            $threshold = SpamAPI_Utils::get_threshold();

            if ($result['is_spam'] && $result['score'] >= $threshold) {
                // Add form error to prevent submission
                wpforms()->process->errors[$form_data['id']]['header'] =
                    __('Your submission has been flagged as spam.', 'spamapi-antispam');
            }
        } catch (SpamAPI_Exception $e) {
            error_log('SpamAPI Error: ' . $e->getMessage());
        }

        return $form_data;
    }

    /**
     * Extract entry data for spam check.
     *
     * @param array $form_data Form configuration.
     * @param array $entry Entry data.
     * @return array Extracted data.
     */
    private function extract_entry_data(array $form_data, array $entry): array {
        $author = '';
        $email = '';
        $content_parts = [];

        if (!empty($form_data['fields'])) {
            foreach ($form_data['fields'] as $field_id => $field) {
                $value = $entry['fields'][$field_id] ?? '';

                switch ($field['type']) {
                    case 'name':
                        if (is_array($value)) {
                            $author = trim(($value['first'] ?? '') . ' ' . ($value['last'] ?? ''));
                        } else {
                            $author = $value;
                        }
                        break;

                    case 'email':
                        $email = $value;
                        break;

                    case 'textarea':
                    case 'text':
                        if (!empty($value)) {
                            $content_parts[] = $value;
                        }
                        break;
                }
            }
        }

        return [
            'user_ip' => SpamAPI_Utils::get_ip_address(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'comment_type' => 'contact-form',
            'comment_author' => $author,
            'comment_author_email' => $email,
            'comment_content' => implode("\n\n", $content_parts),
            'blog_lang' => get_bloginfo('language'),
        ];
    }

}
