<?php
/**
 * SpamAPI comment spam checking.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_Comment {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
    }

    /**
     * Check comment for spam.
     *
     * @param array $commentdata Comment data.
     * @return array Modified comment data.
     */
    public function check_comment(array $commentdata): array {
        // Skip if not enabled or no API key
        if (!get_option('spamapi_enabled', false) || !$this->client->has_api_key()) {
            return $commentdata;
        }

        // Skip for logged-in users who can moderate comments
        if (is_user_logged_in() && current_user_can('moderate_comments')) {
            return $commentdata;
        }

        // Skip for pingbacks/trackbacks (handle separately if needed)
        if (in_array($commentdata['comment_type'] ?? '', ['pingback', 'trackback'], true)) {
            return $commentdata;
        }

        try {
            $result = $this->client->check($this->prepare_check_data($commentdata));

            // Store result in comment meta (will be saved after comment is created)
            $commentdata['spamapi_result'] = $result;

            // Determine if spam based on strictness
            $threshold = SpamAPI_Utils::get_threshold();

            if ($result['is_spam'] && $result['score'] >= $threshold) {
                // Mark as spam
                add_filter('pre_comment_approved', function() {
                    return 'spam';
                });
            } elseif ($result['recommendation'] === 'discard' && $result['score'] >= 0.9) {
                // Blatant spam - optionally reject entirely
                wp_die(
                    __('Your comment has been identified as spam and cannot be submitted.', 'spamapi-antispam'),
                    __('Comment Blocked', 'spamapi-antispam'),
                    ['response' => 403, 'back_link' => true]
                );
            }
        } catch (SpamAPI_Exception $e) {
            // Log error but allow comment through on API failure
            error_log('SpamAPI Error: ' . $e->getMessage());
        }

        return $commentdata;
    }

    /**
     * Log spam status after comment is saved.
     *
     * @param int $comment_id Comment ID.
     * @param int|string $comment_approved Approval status.
     * @param array $commentdata Comment data.
     */
    public function log_spam_status(int $comment_id, $comment_approved, array $commentdata): void {
        if (isset($commentdata['spamapi_result'])) {
            update_comment_meta($comment_id, '_spamapi_result', $commentdata['spamapi_result']);
        }
    }

    /**
     * Add SpamAPI column to comments list.
     *
     * @param array $columns Existing columns.
     * @return array Modified columns.
     */
    public function add_column(array $columns): array {
        $columns['spamapi'] = __('SpamAPI', 'spamapi-antispam');
        return $columns;
    }

    /**
     * Render SpamAPI column content.
     *
     * @param string $column Column name.
     * @param int $comment_id Comment ID.
     */
    public function render_column(string $column, int $comment_id): void {
        if ($column !== 'spamapi') {
            return;
        }

        $result = get_comment_meta($comment_id, '_spamapi_result', true);

        if (empty($result)) {
            echo '<span class="spamapi-status spamapi-status-unknown">—</span>';
            return;
        }

        $score = $result['score'] ?? 0;
        $is_spam = $result['is_spam'] ?? false;

        if ($is_spam) {
            $class = 'spamapi-status-spam';
            $label = sprintf(__('Spam (%s%%)', 'spamapi-antispam'), round($score * 100));
        } else {
            $class = 'spamapi-status-ham';
            $label = sprintf(__('Clean (%s%%)', 'spamapi-antispam'), round((1 - $score) * 100));
        }

        printf(
            '<span class="spamapi-status %s" title="%s">%s</span>',
            esc_attr($class),
            esc_attr(implode(', ', $result['reasons'] ?? [])),
            esc_html($label)
        );
    }

    /**
     * Prepare data for spam check.
     *
     * @param array $commentdata Comment data.
     * @return array Prepared data.
     */
    private function prepare_check_data(array $commentdata): array {
        $post_id = $commentdata['comment_post_ID'] ?? 0;
        $permalink = $post_id ? get_permalink($post_id) : '';

        return [
            'user_ip' => SpamAPI_Utils::get_ip_address(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'referrer' => $_SERVER['HTTP_REFERER'] ?? '',
            'permalink' => $permalink,
            'comment_type' => $commentdata['comment_type'] ?? 'comment',
            'comment_author' => $commentdata['comment_author'] ?? '',
            'comment_author_email' => $commentdata['comment_author_email'] ?? '',
            'comment_author_url' => $commentdata['comment_author_url'] ?? '',
            'comment_content' => $commentdata['comment_content'] ?? '',
            'blog_lang' => get_bloginfo('language'),
        ];
    }

    /**
     * Submit missed spam to SpamAPI.
     *
     * @param int $comment_id Comment ID.
     */
    public function submit_spam(int $comment_id): void {
        $comment = get_comment($comment_id);
        if (!$comment) {
            return;
        }

        try {
            $this->client->submit_spam([
                'user_ip' => $comment->comment_author_IP,
                'comment_type' => $comment->comment_type ?: 'comment',
                'comment_author' => $comment->comment_author,
                'comment_author_email' => $comment->comment_author_email,
                'comment_author_url' => $comment->comment_author_url,
                'comment_content' => $comment->comment_content,
            ]);
        } catch (SpamAPI_Exception $e) {
            error_log('SpamAPI submit_spam error: ' . $e->getMessage());
        }
    }

    /**
     * Submit false positive to SpamAPI.
     *
     * @param int $comment_id Comment ID.
     */
    public function submit_ham(int $comment_id): void {
        $comment = get_comment($comment_id);
        if (!$comment) {
            return;
        }

        try {
            $this->client->submit_ham([
                'user_ip' => $comment->comment_author_IP,
                'comment_type' => $comment->comment_type ?: 'comment',
                'comment_author' => $comment->comment_author,
                'comment_author_email' => $comment->comment_author_email,
                'comment_author_url' => $comment->comment_author_url,
                'comment_content' => $comment->comment_content,
            ]);
        } catch (SpamAPI_Exception $e) {
            error_log('SpamAPI submit_ham error: ' . $e->getMessage());
        }
    }
}
