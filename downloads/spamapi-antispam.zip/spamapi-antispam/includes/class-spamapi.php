<?php
/**
 * Main SpamAPI plugin class.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI {
    /**
     * Plugin instance.
     *
     * @var SpamAPI|null
     */
    private static ?SpamAPI $instance = null;

    /**
     * API client instance.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * Admin instance.
     *
     * @var SpamAPI_Admin
     */
    private SpamAPI_Admin $admin;

    /**
     * Comment handler instance.
     *
     * @var SpamAPI_Comment
     */
    private SpamAPI_Comment $comment;

    /**
     * Get plugin instance.
     *
     * @return SpamAPI
     */
    public static function get_instance(): SpamAPI {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->load_textdomain();
        $this->init_components();
        $this->init_hooks();
    }

    /**
     * Load plugin text domain.
     */
    private function load_textdomain(): void {
        load_plugin_textdomain(
            'spamapi-antispam',
            false,
            dirname(SPAMAPI_PLUGIN_BASENAME) . '/languages'
        );
    }

    /**
     * Initialize plugin components.
     */
    private function init_components(): void {
        $api_key = get_option('spamapi_api_key', '');
        $api_url = get_option('spamapi_api_url', SPAMAPI_API_URL);

        $this->client = new SpamAPI_Client($api_key, $api_url);
        $this->admin = new SpamAPI_Admin($this->client);
        $this->comment = new SpamAPI_Comment($this->client);

        // Initialize integrations if plugins are active
        if ($this->is_enabled()) {
            $this->init_integrations();
        }
    }

    /**
     * Initialize plugin hooks.
     */
    private function init_hooks(): void {
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', [$this->admin, 'add_menu']);
            add_action('admin_init', [$this->admin, 'register_settings']);
            add_action('admin_enqueue_scripts', [$this->admin, 'enqueue_scripts']);
            add_filter('plugin_action_links_' . SPAMAPI_PLUGIN_BASENAME, [$this->admin, 'add_action_links']);
        }

        // Comment hooks
        add_filter('preprocess_comment', [$this->comment, 'check_comment'], 1);
        add_action('comment_post', [$this->comment, 'log_spam_status'], 10, 3);

        // Admin column for comments
        add_filter('manage_edit-comments_columns', [$this->comment, 'add_column']);
        add_action('manage_comments_custom_column', [$this->comment, 'render_column'], 10, 2);

        // REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    /**
     * Initialize form plugin integrations.
     */
    private function init_integrations(): void {
        // Contact Form 7
        if (class_exists('WPCF7')) {
            new SpamAPI_CF7($this->client);
        }

        // Gravity Forms
        if (class_exists('GFForms')) {
            new SpamAPI_Gravity_Forms($this->client);
        }

        // WPForms
        if (function_exists('wpforms')) {
            new SpamAPI_WPForms($this->client);
        }
    }

    /**
     * Register REST API routes.
     */
    public function register_rest_routes(): void {
        $rest = new SpamAPI_REST($this->client);
        $rest->register_routes();
    }

    /**
     * Check if plugin is enabled and configured.
     *
     * @return bool
     */
    public function is_enabled(): bool {
        return get_option('spamapi_enabled', false) && !empty(get_option('spamapi_api_key', ''));
    }

    /**
     * Get API client.
     *
     * @return SpamAPI_Client
     */
    public function get_client(): SpamAPI_Client {
        return $this->client;
    }

    /**
     * Plugin activation.
     */
    public static function activate(): void {
        // Set default options
        add_option('spamapi_enabled', false);
        add_option('spamapi_api_key', '');
        add_option('spamapi_api_url', SPAMAPI_API_URL);
        add_option('spamapi_strictness', 'balanced'); // lenient, balanced, strict

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation.
     */
    public static function deactivate(): void {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
