<?php
/**
 * SpamAPI Utility class.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_Utils {
    /**
     * Get client IP address.
     *
     * @return string IP address.
     */
    public static function get_ip_address(): string {
        // Use WPForms helper if available as it's robust
        if (function_exists('wpforms_get_ip')) {
            return wpforms_get_ip();
        }

        // Use Gravity Forms helper if available
        if (class_exists('GFFormsModel')) {
            return GFFormsModel::get_ip();
        }

        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Get spam score threshold based on strictness setting.
     *
     * @return float Threshold value (0.0 to 1.0).
     */
    public static function get_threshold(): float {
        $strictness = get_option('spamapi_strictness', 'balanced');
        return SPAMAPI_SCORE_THRESHOLDS[$strictness] ?? 0.5;
    }
}
