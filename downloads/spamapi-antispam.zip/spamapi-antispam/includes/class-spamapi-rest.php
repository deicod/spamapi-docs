<?php
/**
 * SpamAPI REST API endpoints for admin operations.
 *
 * @package SpamAPI_Antispam
 */

class SpamAPI_REST {
    /**
     * API client.
     *
     * @var SpamAPI_Client
     */
    private SpamAPI_Client $client;

    /**
     * REST namespace.
     *
     * @var string
     */
    private string $namespace = 'spamapi/v1';

    /**
     * Constructor.
     *
     * @param SpamAPI_Client $client API client.
     */
    public function __construct(SpamAPI_Client $client) {
        $this->client = $client;
    }

    /**
     * Register REST routes.
     */
    public function register_routes(): void {
        // Test connection endpoint
        register_rest_route($this->namespace, '/test', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'test_connection'],
            'permission_callback' => [$this, 'admin_permission_check'],
        ]);

        // Get usage stats
        register_rest_route($this->namespace, '/usage', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_usage'],
            'permission_callback' => [$this, 'admin_permission_check'],
        ]);

        // Submit spam feedback
        register_rest_route($this->namespace, '/submit-spam/(?P<id>\d+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'submit_spam'],
            'permission_callback' => [$this, 'moderate_permission_check'],
            'args' => [
                'id' => [
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    },
                ],
            ],
        ]);

        // Submit ham feedback
        register_rest_route($this->namespace, '/submit-ham/(?P<id>\d+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'submit_ham'],
            'permission_callback' => [$this, 'moderate_permission_check'],
            'args' => [
                'id' => [
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    },
                ],
            ],
        ]);
    }

    /**
     * Check if user can manage options.
     *
     * @return bool
     */
    public function admin_permission_check(): bool {
        return current_user_can('manage_options');
    }

    /**
     * Check if user can moderate comments.
     *
     * @return bool
     */
    public function moderate_permission_check(): bool {
        return current_user_can('moderate_comments');
    }

    /**
     * Test API connection.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response.
     */
    public function test_connection(WP_REST_Request $request): WP_REST_Response|WP_Error {
        try {
            $result = $this->client->verify_key();
            return new WP_REST_Response([
                'success' => true,
                'valid' => $result['valid'] ?? false,
                'plan' => $result['plan'] ?? null,
            ]);
        } catch (SpamAPI_Exception $e) {
            return new WP_Error(
                $e->get_error_code(),
                $e->getMessage(),
                ['status' => $e->get_status_code() ?: 500]
            );
        }
    }

    /**
     * Get usage statistics.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response.
     */
    public function get_usage(WP_REST_Request $request): WP_REST_Response|WP_Error {
        try {
            $usage = $this->client->get_usage();
            return new WP_REST_Response($usage);
        } catch (SpamAPI_Exception $e) {
            return new WP_Error(
                $e->get_error_code(),
                $e->getMessage(),
                ['status' => $e->get_status_code() ?: 500]
            );
        }
    }

    /**
     * Submit spam feedback for a comment.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response.
     */
    public function submit_spam(WP_REST_Request $request): WP_REST_Response|WP_Error {
        $comment_id = absint($request->get_param('id'));

        if ($comment_id <= 0) {
            return new WP_Error('invalid_param', 'Invalid comment ID', ['status' => 400]);
        }

        $comment = get_comment($comment_id);

        if (!$comment) {
            return new WP_Error('not_found', 'Comment not found', ['status' => 404]);
        }


        $comment_handler = new SpamAPI_Comment($this->client);

        try {
            $comment_handler->submit_spam($comment_id);
            return new WP_REST_Response(['success' => true]);
        } catch (SpamAPI_Exception $e) {
            return new WP_Error(
                $e->get_error_code(),
                $e->getMessage(),
                ['status' => $e->get_status_code() ?: 500]
            );
        }
    }

    /**
     * Submit ham feedback for a comment.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response.
     */
    public function submit_ham(WP_REST_Request $request): WP_REST_Response|WP_Error {
        $comment_id = absint($request->get_param('id'));

        if ($comment_id <= 0) {
            return new WP_Error('invalid_param', 'Invalid comment ID', ['status' => 400]);
        }

        $comment = get_comment($comment_id);

        if (!$comment) {
            return new WP_Error('not_found', 'Comment not found', ['status' => 404]);
        }

        $comment_handler = new SpamAPI_Comment($this->client);

        try {
            $comment_handler->submit_ham($comment_id);
            return new WP_REST_Response(['success' => true]);
        } catch (SpamAPI_Exception $e) {
            return new WP_Error(
                $e->get_error_code(),
                $e->getMessage(),
                ['status' => $e->get_status_code() ?: 500]
            );
        }
    }
}
