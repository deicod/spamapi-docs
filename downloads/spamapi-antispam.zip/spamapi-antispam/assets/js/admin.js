jQuery(document).ready(function($) {
    $('#spamapi-test-connection').on('click', function() {
        var $button = $(this);
        var $result = $('#spamapi-test-result');
        var apiKey = $('input[name="spamapi_api_key"]').val();
        var apiUrl = $('input[name="spamapi_api_url"]').val();

        if (!apiKey) {
            $result.css('color', '#dc3232').text('Please enter an API key first.');
            return;
        }

        // Disable button and show testing message
        $button.prop('disabled', true);
        $result.css('color', '#0073aa').text(spamapiAdmin.strings.testing);

        // Make AJAX request to REST API
        $.ajax({
            url: spamapiAdmin.restUrl + 'test',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', spamapiAdmin.restNonce);
            },
            data: {
                api_key: apiKey
            }
        }).done(function(response) {
            $button.prop('disabled', false);
            if (response.valid) {
                 $result.css('color', '#46b450').text(spamapiAdmin.strings.success + ' (' + response.plan + ')');
            } else {
                 $result.css('color', '#dc3232').text(spamapiAdmin.strings.error + ' Invalid Key');
            }
        }).fail(function(response) {
            $button.prop('disabled', false);
            var msg = response.responseJSON && response.responseJSON.message ? response.responseJSON.message : 'Unknown error';
            $result.css('color', '#dc3232').text(spamapiAdmin.strings.error + ' ' + msg);
        });
    });
});
