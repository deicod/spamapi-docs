<?php
/**
 * Plugin Name: SpamAPI Anti-Spam
 * Plugin URI: https://deicod.github.io/spamapi-docs/guides/wordpress-plugin/
 * Description: Protect your WordPress site from spam comments and form submissions using SpamAPI's intelligent spam detection.
 * Version: 1.0.1
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: SpamAPI
 * Author URI: https://github.com/deicod
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: spamapi-antispam
 * Domain Path: /languages
 *
 * @package SpamAPI_Antispam
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('SPAMAPI_VERSION', '1.0.1');
define('SPAMAPI_PLUGIN_FILE', __FILE__);
define('SPAMAPI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SPAMAPI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SPAMAPI_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Configuration Constants
define('SPAMAPI_API_URL', 'https://spamapi.de/api/v1');
define('SPAMAPI_SCORE_THRESHOLDS', [
    'lenient' => 0.8,
    'balanced' => 0.5,
    'strict' => 0.3,
]);

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'SpamAPI_';
    if (strpos($class, $prefix) !== 0) {
        return;
    }

    $class_name = substr($class, strlen($prefix));
    $class_name = strtolower(str_replace('_', '-', $class_name));

    $file = SPAMAPI_PLUGIN_DIR . 'includes/class-spamapi-' . $class_name . '.php';
    if (!file_exists($file)) {
        $file = SPAMAPI_PLUGIN_DIR . 'includes/integrations/class-spamapi-' . $class_name . '.php';
    }
    if (file_exists($file)) {
        require_once $file;
    }
});

// Load main class
require_once SPAMAPI_PLUGIN_DIR . 'includes/class-spamapi.php';

// Initialize plugin
function spamapi_init() {
    // Upgrade the retired hosted default while preserving self-hosted URLs.
    if (get_option('spamapi_api_url') === 'https://api.spamapi.de/v1') {
        update_option('spamapi_api_url', SPAMAPI_API_URL);
    }
    if (class_exists('SpamAPI')) {
        return SpamAPI::get_instance();
    }
}
add_action('plugins_loaded', 'spamapi_init');

// Activation hook
register_activation_hook(__FILE__, ['SpamAPI', 'activate']);

// Deactivation hook
register_deactivation_hook(__FILE__, ['SpamAPI', 'deactivate']);
